<?php 
session_start();
include('Model/c_login.php');
include('Controller/c_login.php');
include('View/login/index.php');
?>