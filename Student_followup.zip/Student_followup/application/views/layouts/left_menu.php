 <?php 
session_start();
  ?>
 <!-- Side Navbar -->
    <nav class="side-navbar">
      <div class="side-navbar-wrapper">
        <!-- Sidebar Header    -->
        <div class="sidenav-header d-flex align-items-center justify-content-center">
          <!-- User Info-->
          <div class="sidenav-header-inner text-center">
            <h2 class="h5">Welcome, 
              <?php 
              // if(isset($_SESSION['user_name']))
              // {
              //   echo $_SESSION['user_name'];
              // }
               ?>


            </h2><span>Web 2018</span>
          </div>
          <!-- Small Brand information, appears on minimized sidebar -->
          <div class="sidenav-header-logo"><a href="index.html" class="brand-small text-center"> <strong>S</strong><strong class="text-primary">D</strong></a></div>
        </div>
       <!--  Sidebar Navigation Menus -->
        <div class="main-menu">
          <h5 class="sidenav-heading">Main</h5>
          <ul id="side-main-menu" class="side-menu list-unstyled">                  
            <?php 
            // if($_SESSION['user_role'] == 1){
             ?>
             <!-- show teacher menu -->
                  <li><a href="<?php echo base_url();?>welcome/load_dashboard" aria-expanded="false" data-toggle="collapse"> <i class="icon-user"></i>Followup List</a>
                    <ul id="student" class="collapse list-unstyled ">
                      <li id="hide_show_menu1" class="student"><a href=""> <i class="icon-form"></i>Manage Schedule</a></li>
                      <li id="hide_show_menu1" class="student"><a href="template.php?page=teacher&fun=list"> <i class="icon-form"></i>Manage student</a></li>
                      <li id="hide_show_menu1" class="student"><a href="template.php?page=teacher&fun=list"> <i class="icon-form"></i>View attdence</a></li>
                      <li id="hide_show_menu1" class="student"><a href="template.php?page=teacher&fun=list"> <i class="icon-form"></i>List Schedule</a></li>
                      <li id="hide_show_menu2" class="attendent"><a href="template.php?page=schedule&fun=view_attendance"> <i class="fa fa-bar-chart"></i>Get Attendence</a></li>
                      <li id="hide_show_menu3" class="schedule"><a href="#"> <i class="icon-grid"></i>Student List</a></li>
                    </ul>
                  </li>
                 
            
           
          </ul>
    </nav>