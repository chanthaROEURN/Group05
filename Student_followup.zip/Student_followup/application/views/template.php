<?php 
  $this->load->view("layouts/header");
  $this->load->view("layouts/left_menu");
  $this->load->view("$page");
  $this->load->view("layouts/footer");
 ?>
     