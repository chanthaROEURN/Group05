 <div class="viewSchedule">
          <header> 
            <h1 class="text-center">Student Cleaning Schedule</h1>
          </header>
          <div class="row">
        <div class="col-lg-12">
              <div class="card">
                <div class="card-body">
                  <div class="table-responsive">
                   <table class="table table-bordered">
                       <thead>
                         <tr>
                           <th>Date</th>
                           <th>Mon 3/26</th>
                           <th>Tue 3/271</th>
                           <th>Wed 3/28</th>
                           <th>Thu 3/2</th>
                           <th>Fri 3/30</th>
                           <th>Sat 3/31</th>
                           <th>Sun 4/1</th>
                         </tr>
                       </thead>
                       <tbody>
                         <tr>
                           <td>7am</td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                         </tr>
                         <tr>
                           <td>8am</td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                         </tr>
                         <tr>
                           <td>9am</td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                         </tr>
                         <tr>
                           <td>10am</td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                         </tr>
                         <tr>
                           <td>11am</td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                         </tr>
                         <tr>
                           <td>12pm</td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                         </tr>
                         <tr>
                           <td>1pm</td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                         </tr>
                         <tr>
                           <td>2pm</td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                         </tr>
                         <tr>
                           <td>3pm</td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                         </tr>
                         <tr>
                           <td>4pm</td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                         </tr>
                         <tr>
                           <td>5pm</td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                         </tr>

                       </tbody>
                     </table>
                  </div>
                </div>
              </div>
            </div>         
          </div>
        </div>
      </section>
      <!-- end view schedule -->