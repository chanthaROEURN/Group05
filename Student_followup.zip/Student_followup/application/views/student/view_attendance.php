<!-- get attendence -->
      <section>
        <div class="getAttendence">
          <header> 
            <h1 class="text-center">Student Cleaning Schedule</h1>
          </header>
          <div class="row">
        <div class="col-lg-12">
              <div class="card">
                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th>ID</th>
                          <th>Student Name</th>
                          <th>Class</th>
                          <th>Action</th>
                          <th>Submit</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <th>10</th>
                          <td>Saroeurt Samreth</td>
                          <td>WEB-2018</td>
                          <td>
                            <div class="i-checks">
                              <input id="checkboxCustom2" type="checkbox" value="" checked="" class="form-control-custom">
                              <label for="checkboxCustom2">checked</label>
                            </div>
                          </td>
                          <td>
                            <button type="submit" class="btn btn-primary">Send</button>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>         
          </div>
        </div>
      </section>
      <!-- end get attendence -->
