
      <!-- student list -->
      <section>
        <div class="studentList">
          <!-- Page Header-->
          <header> 
            <h1 class="text-center">Student Cleaning Schedule</h1>
          </header>
          <div class="row">
          <div class="col-lg-12">
            <div class="card">
              <div class="card-header">
                <h4 class="text-center">Group 4</h4>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table table-striped">
                    <thead>
                      <tr>
                        <th>ID</th>
                        <th>Student Name</th>
                        <th>Class</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                       <th>10</th>
                       <td>Saroeurt Samreth</td>
                       <td>WEB-2018</td>
                      </tr>
                      <tr>
                       <th>11</th>
                       <td>Sok Daken</td>
                       <td>WEB-2018</td>
                      </tr>
                      <tr>
                       <th>12</th>
                       <td>Roeurn Chantha</td>
                       <td>WEB-2018</td>
                      </tr>
                      <tr>
                       <th>13</th>
                       <td>Poeung Davy</td>
                       <td>WEB-2018</td>
                      </tr>
                      <tr>
                       <th>14</th>
                       <td>Chea Devit </td>
                       <td>WEB-2018</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>       
          </div>
        </div>
      </section>
      <!-- end student list -->