<?php

class c_login extends CI_Controller {
	public function login(){
		$email =  $this->input->post('email');
			echo $email;
		$password =  $this->input->post('password');
			echo $password;
	}

	
}
