 $(document).ready(function() {
  $('.view_student').show();
  $('.view_attendent').hide();
  $('.manage_schedule').hide();

    $('#hide_show_menu2').click(function() {
      $('.view_student').show("slow");
      $('.view_attendent').hide("slow");
      $('.manage_schedule').hide("slow");
    });
    $('#hide_show_menu1').click(function() {
      $('.view_student').hide("slow");
      $('.view_attendent').show("slow");
      $('.manage_schedule').hide("slow");
    });
    $('#hide_show_menu3').click(function() {
      $('.view_student').hide("slow");
      $('.view_attendent').hide("slow");
      $('.manage_schedule').show("slow");
    });
});