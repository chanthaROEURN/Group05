 $(document).ready(function() {
  // $('.viewSchedule').show();
  // $('.getAttendence').hide();
  // $('.studentList').hide();

  //   $('#hide_show_menu1').click(function() {
  //     $('.viewSchedule').show("");
  //     $('.studentList').hide("");
  //     $('.getAttendence').hide("");
  //   });
  //   $('#hide_show_menu2').click(function() {
  //     $('.getAttendence').show("");
  //     $('.viewSchedule').hide("");
  //     $('.studentList').hide("");
  //   });
  //   $('#hide_show_menu3').click(function() {
  //     $('.studentList').show("");
  //     $('.viewSchedule').hide("");
  //     $('.getAttendence').hide("");
  //   });
});